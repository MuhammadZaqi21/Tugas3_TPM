# Tugas-3-RecyclerView-Intent---Prak-TPM
# RECYCLER VIEW & INTENT
Nama : Muhammad Ibnu Zaqi
\nNIM : 123180164
Praktikum Teknologi Pemrograman Mobile - Plug C
link Github: https://github.com/MuhammadZaqi21/Tugas3_TPM
Link Video Penjelasan : https://youtu.be/B8zzx2H-d6Y
